import java.util.*;

public class Evolution {
    private String pokemonName;
    private String evolvedForm;

    public Evolution(String pokemonName, String evolvedForm) {
        this.pokemonName = pokemonName;
        this.evolvedForm = evolvedForm;
    }

    public void evolve() {
        System.out.println(pokemonName + " is evolving into " + evolvedForm + "!");
        // Add logic to perform the evolution here
    }

    public static void main(String[] args) {
        Evolution pikachuEvolution = new Evolution("Pikachu", "Raichu");
        pikachuEvolution.evolve();
    }
}