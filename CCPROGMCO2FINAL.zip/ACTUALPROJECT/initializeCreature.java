import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.ImageIcon;

public class initializeCreature {

    public static ArrayList<Creature> readCreaturesFromFile(String filePath) {
        ArrayList<Creature> allCreatures = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");

                if (data.length == 8) { // Adjusted to 8 for the image path
                    Creature creature = new Creature();
                    creature.setcName(data[0].trim());
                    creature.setcType(data[1].trim());
                    creature.setcFam(data[2].trim());
                    creature.setcHealth(Integer.parseInt(data[3].trim()));
                    creature.setcEvLvl(Integer.parseInt(data[4].trim()));
                    creature.setIsActive(Boolean.parseBoolean(data[5].trim()));
                    creature.setIsEnemy(Boolean.parseBoolean(data[6].trim()));

                    // Set the image file path and create the ImageIcon
                    String imagePath = data[7].trim();
                    creature.setCreatureImage(new ImageIcon(imagePath));

                    allCreatures.add(creature);
                } else {
                    System.out.println("Invalid data format in line: " + line);
                }
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }

        return allCreatures;
    }

    public static void main(String[] args) {
        // Provide the path to your creatures file
        String filePath = "C:/Users/disav/Desktop/Codes/CCPROG3 MCO2 ACTUAL/creatures.txt";
        ArrayList<Creature> creaturesList = readCreaturesFromFile(filePath);

        // Print the creatures information
        for (Creature creature : creaturesList) {
            System.out.println("Name: " + creature.getcName());
            System.out.println("Family: " + creature.getcFam());
            System.out.println("Image Path: " + ((creature.getCreatureImage() != null) ? "Present" : "Not specified"));
        }
    }
}
