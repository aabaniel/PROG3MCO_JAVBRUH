import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

public class battlephaseMenu {
    private JFrame battleFrame;
    private JTextArea creatureDetailsTextArea;
    private JTextArea enemyCreatureText;
    private JLabel enemyImageLabel;
    private JLabel creatureImageLabel;
    private ArrayList<Creature> creaturesList;
    private ArrayList<Creature> allCreatures;
    private Creature aCreature; 
    private Creature enemyCreature;
    private boolean attackUsed = false;
    private boolean swapUsed = false;
    private boolean catchUsed = false;

    public battlephaseMenu(int x, int y, ArrayList<Creature> allCreatures,ArrayList<Creature> creaturesList,int areaEL) {
        
        this.creaturesList = creaturesList;
        this.allCreatures = allCreatures;

       
        battleFrame = new JFrame("Battle Phase");
        battleFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        battleFrame.setSize(1230, 720);
        battleFrame.setLayout(null);

        ImageIcon backgroundImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/BlankBackground.png");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, battleFrame.getWidth(), battleFrame.getHeight());
        

        creatureDetailsTextArea = new JTextArea();
        creatureDetailsTextArea.setBounds(650, 500, 500, 250);
        creatureDetailsTextArea.setEditable(false);
        creatureDetailsTextArea.setFont(new Font("Monospaced", Font.PLAIN, 28));
        creatureDetailsTextArea.setForeground(new Color(75, 11, 14));
        creatureDetailsTextArea.setOpaque(false);
;

        creatureImageLabel = new JLabel();
        creatureImageLabel.setBounds(800, 250, 250, 250);
         enemyCreatureText = new JTextArea();
        enemyCreatureText.setBounds(200, 350, 500, 250);
        enemyCreatureText.setEditable(false);
        enemyCreatureText.setFont(new Font("Monospaced", Font.PLAIN, 28));
        enemyCreatureText.setForeground(new Color(75, 11, 14));
        enemyCreatureText.setOpaque(false);

        enemyImageLabel = new JLabel();
        enemyImageLabel.setBounds(200, 100, 250, 250);

        
        displayCreatures(creaturesList, allCreatures, areaEL);
        Icon swap = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/SWAP.png");
        JButton swapButton = new JButton(swap);
        swapButton.setBounds(225, 550, 94, 94);
        swapButton.setBackground(new Color(75, 11, 14));
        swapButton.setForeground(new Color(243, 237, 217));
        swapButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                if(!swapUsed)
                {
                openInventoryMenu();
                swapUsed = true;

                }
                else
                {
                    JOptionPane.showMessageDialog(battleFrame, "Swap already used!");
                }  
                updateDisplay(creaturesList,allCreatures);
            }
        });
       Icon catchC = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/CATCH.png");
        JButton catchButton = new JButton(catchC);
        catchButton.setBounds(350, 550, 94, 94);
        catchButton.setBackground(new Color(75, 11, 14));
        catchButton.setForeground(new Color(243, 237, 217));
        catchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                if(!catchUsed)
                {
                catchCreature(creaturesList, enemyCreature);
                catchUsed = true;

                }
                else
                {
                    JOptionPane.showMessageDialog(battleFrame, "Catch already used!");
                }  
              
            }
        });
        
        Icon attack = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/ATK.png");
        JButton attackButton = new JButton(attack);
        attackButton.setBounds(475, 550, 94, 94);
        attackButton.setBackground(new Color(75, 11, 14));
        attackButton.setForeground(new Color(243, 237, 217));
        attackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!attackUsed)
                {
                attack(aCreature, enemyCreature);
                attackUsed = true;

                }
                else
                {
                    JOptionPane.showMessageDialog(battleFrame, "Attack already used!");
                }  
                updateDisplay(creaturesList,allCreatures);
            }
        });
        Icon run = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/RUN.png");
        JButton runButton = new JButton(run);
        runButton.setBounds(100, 550, 94, 94);
        runButton.setBackground(new Color(75, 11, 14));
        runButton.setForeground(new Color(243, 237, 217));
        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                runAway(x, y, creaturesList,allCreatures, areaEL);
                }
        });


        
        battleFrame.add(creatureDetailsTextArea);
        battleFrame.add(creatureImageLabel);
        battleFrame.add(attackButton);
        battleFrame.add(swapButton);
        battleFrame.add(runButton);
        battleFrame.add(catchButton);
        
        battleFrame.add(enemyCreatureText);
        battleFrame.add(enemyImageLabel);
         battleFrame.add(backgroundLabel);
        battleFrame.setVisible(true);
  
        

    }

    private void displayCreatures(ArrayList<Creature> creaturesList, ArrayList<Creature> allCreatures, int areaEL) {
       

        
        for (Creature creature : creaturesList) {
            if (creature.getIsActive()) {
                aCreature = creature;
                break;
            }
        }

       
        Random random = new Random();
        ArrayList<Creature> eligibleEnemies = new ArrayList<>();

        for (Creature creature : allCreatures) {
            if (creature.getcEvLvl() <= areaEL) {
                eligibleEnemies.add(creature);

            }
        }

        
        if (!eligibleEnemies.isEmpty()) {
            int randomIndex = random.nextInt(eligibleEnemies.size());
            enemyCreature = eligibleEnemies.get(randomIndex);
            
        }
     
        
        creatureDetailsTextArea.append("Active Player Creature Details:\n");
        creatureDetailsTextArea.append("Name: " + aCreature.getcName() + "\n");
        creatureDetailsTextArea.append("Type: " + aCreature.getcType() + "\n");
        creatureDetailsTextArea.append("Health: " + aCreature.getcHealth() + "\n");
        creatureImageLabel.setIcon(aCreature.getCreatureImage());


        
        enemyCreatureText.append("Enemy Creature: \n");
        enemyCreatureText.append("Name: " + enemyCreature.getcName() + "\n");
        enemyCreatureText.append("Type: " + enemyCreature.getcType() + "\n");
        enemyCreatureText.append("Health: " + enemyCreature.getcHealth() + "\n");
        enemyImageLabel.setIcon(enemyCreature.getCreatureImage());


       
    }

    private void updateDisplay(ArrayList<Creature> creaturesList, ArrayList<Creature> allCreatures) {
                     if (swapUsed && catchUsed && attackUsed) {
            JOptionPane.showMessageDialog(battleFrame, "Enemy ran away!"); 
                         battleFrame.dispose();
              areaMenu areaInstance = new areaMenu(allCreatures, creaturesList);
             areaInstance.mainFrame.dispose();

        }
       
       
       
        creatureDetailsTextArea.setText("");
        creatureDetailsTextArea.append("Active Player Creature Details:\n");
        creatureDetailsTextArea.append("Name: " + aCreature.getcName() + "\n");
        creatureDetailsTextArea.append("Type: " + aCreature.getcType() + "\n");
        creatureDetailsTextArea.append("Health: " + aCreature.getcHealth() + "\n");
        creatureImageLabel.setIcon(aCreature.getCreatureImage());

        enemyCreatureText.setText("");
        enemyCreatureText.append("Enemy Creature: \n");
        enemyCreatureText.append("Name: " + enemyCreature.getcName() + "\n");
        enemyCreatureText.append("Type: " + enemyCreature.getcType() + "\n");
        enemyCreatureText.append("Health: " + enemyCreature.getcHealth() + "\n");
        enemyImageLabel.setIcon(enemyCreature.getCreatureImage());
        
  
        
    }

    private void attack(Creature aCreature, Creature enemyCreature) {
        if (aCreature != null && enemyCreature != null) {
           
           

            Random random = new Random();
            int baseDamage = (random.nextInt(10) + 1) * aCreature.getcEvLvl();
            if (isElement(aCreature, enemyCreature)) {
                baseDamage *= 1.5;
                JOptionPane.showMessageDialog(battleFrame, "Element Advantage! Bonus x1.5 Damage");
            }

            enemyCreature.setcHealth(enemyCreature.getcHealth() - baseDamage);

            JOptionPane.showMessageDialog(battleFrame, "Creature " + aCreature.getcName() + " attacks " + enemyCreature.getcName() + " for " + baseDamage + " damage. Enemy " + enemyCreature.getcName() + " now has " + enemyCreature.getcHealth() + " HP.");


        }
    }
    private boolean isElement(Creature creature, Creature enemyCreature) {
        /*
         isElement(creature, enemyCreature): checks the types of the user creature and enemy creature  
         
         */
        String creatureType = creature.getcType();
        String enemyType = enemyCreature.getcType();

        return (creatureType.equalsIgnoreCase("Vanilla") && enemyType.equalsIgnoreCase("Banana")) ||
            (creatureType.equalsIgnoreCase("Banana") && enemyType.equalsIgnoreCase("Chocolate")) ||
            (creatureType.equalsIgnoreCase("Chocolate") && enemyType.equalsIgnoreCase("Vanilla"));
    }

    public void updateActiveCreature(Creature newActiveCreature) {
        if (aCreature != null) {
            aCreature.setIsActive(false);
        }

        aCreature = newActiveCreature;
        aCreature.setIsActive(true);

        updateDisplay(creaturesList, allCreatures);
    }

    private void openInventoryMenu() {

        new battleInventoryMenu(this, creaturesList, allCreatures);
        
    }

    private void catchCreature(ArrayList<Creature> creaturesList, Creature enemyCreature) 
    {
        Random random = new Random();
        double chance = (double)(40 + 50 - enemyCreature.cHealth) / 100;
        if (random.nextDouble() < chance)
        {
            JOptionPane.showMessageDialog(battleFrame, "You caught creature: " + enemyCreature.cName + "!");
            enemyCreature.IsEnemy = false;
            enemyCreature.IsActive = false;
            creaturesList.add(enemyCreature);
            JOptionPane.showMessageDialog(battleFrame, "Going back!");
             battleFrame.dispose();
              areaMenu areaInstance = new areaMenu(allCreatures, creaturesList);
             areaInstance.mainFrame.dispose();
          }  

        else
             JOptionPane.showMessageDialog(battleFrame, "Failed!");
    }

    private void runAway(int x, int y, ArrayList<Creature> allCreatures, ArrayList<Creature> creaturesList, int areaEL) {
        battleFrame.dispose();
        areaMenu areaInstance = new areaMenu(allCreatures, creaturesList);
        areaInstance.mainFrame.dispose();
    }

}
