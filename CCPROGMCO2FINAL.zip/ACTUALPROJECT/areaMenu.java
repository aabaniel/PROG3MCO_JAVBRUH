import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class areaMenu {
    public JFrame mainFrame;
    public JFrame area1Frame;
    private JPanel tablePanel;
    private int currentX = 0; 
    private int currentY = 0; 
    ArrayList<Creature> creaturesList;
    ArrayList<Creature> allCreatures;

    public areaMenu(ArrayList<Creature> allCreatures, ArrayList<Creature> creaturesList) {
        mainFrame = new JFrame("Pokemon Sundae");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(1230, 720);
        mainFrame.setLayout(null);

        
        ImageIcon backgroundImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Menu.png");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, mainFrame.getWidth(), mainFrame.getHeight());

        mainFrame.add(backgroundLabel);

        JButton area1 = new JButton("banana beach");
        area1.setBounds(370, 350, 400, 75);
        area1.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 26));
        area1.setBackground(new Color(75, 11, 14));
        area1.setForeground(new Color(243, 237, 217));
        area1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.dispose();
                area(5,1,1, allCreatures, creaturesList);
            }
        });
        JButton area2 = new JButton("vanilla valley");
        area2.setBounds(370, 450, 400, 75);
        area2.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 26));
        area2.setBackground(new Color(75, 11, 14));
        area2.setForeground(new Color(243, 237, 217));
        area2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.dispose();
                area(3,3,2, allCreatures, creaturesList);
            }
        });

        JButton area3 = new JButton("chocolate cove");
        area3.setBounds(370, 550, 400, 75);
        area3.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 26));
        area3.setBackground(new Color(75, 11, 14));
        area3.setForeground(new Color(243, 237, 217));
        area3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.dispose();
                area(4,4,3, allCreatures, creaturesList);
            }
        });


        backgroundLabel.add(area1);
        backgroundLabel.add(area2);
        backgroundLabel.add(area3);
        mainFrame.setVisible(true);
    }

 
    public void area(int x, int y, int areaEL, ArrayList<Creature> allCreatures,ArrayList<Creature> creaturesList) {

        mainFrame.dispose();
         
        
        JFrame area1Frame = new JFrame("Area");
        area1Frame.setSize(1230, 720);
        area1Frame.setLayout(new BorderLayout());

        
        tablePanel = new JPanel(new GridLayout(y, x));
        updateTable(x, y); 

        
        JButton leftButton = new JButton("Left");
        leftButton.setFont(new Font("Monocraft", Font.PLAIN, 15));
        leftButton.setBackground(new Color(75, 11, 14));
        leftButton.setForeground(new Color(243, 237, 217)); 
        leftButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveLeft(y, x, allCreatures, creaturesList, areaEL);
            }
        });

        JButton upButton = new JButton("Up");
        upButton.setFont(new Font("Monocraft", Font.PLAIN, 15));
        upButton.setBackground(new Color(75, 11, 14));
        upButton.setForeground(new Color(243, 237, 217));     
        upButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveUp(y, x, allCreatures, creaturesList, areaEL);
            }
        });

        JButton downButton = new JButton("Down");
        downButton.setFont(new Font("Monocraft", Font.PLAIN, 15));
        downButton.setBackground(new Color(75, 11, 14));
        downButton.setForeground(new Color(243, 237, 217));
        downButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveDown(y,x, allCreatures, creaturesList, areaEL);
            }
        });


        JButton rightButton = new JButton("Right");
        rightButton.setFont(new Font("Monocraft", Font.PLAIN, 15));
        rightButton.setBackground(new Color(75, 11, 14));
        rightButton.setForeground(new Color(243, 237, 217));
        rightButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveRight(y, x, allCreatures, creaturesList, areaEL);
            }
        });

        JButton backButton = new JButton("Exit");
        backButton.setFont(new Font("Monocraft", Font.PLAIN, 15));
        backButton.setBackground(new Color(75, 11, 14));
        backButton.setForeground(new Color(243, 237, 217));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                area1Frame.dispose(); 
                mainMenu.pokemonSundae(creaturesList);
            }
        });

        
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2)); 
        buttonPanel.add(leftButton);
        buttonPanel.add(upButton);
        buttonPanel.add(downButton);
        buttonPanel.add(rightButton);

        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.add(buttonPanel, BorderLayout.NORTH);
        controlPanel.add(backButton, BorderLayout.SOUTH);

        area1Frame.add(controlPanel, BorderLayout.WEST);
        area1Frame.add(tablePanel, BorderLayout.CENTER);
        area1Frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        area1Frame.setVisible(true);
    }
    

    private void moveLeft(int x, int y, ArrayList<Creature> allCreatures,ArrayList<Creature> creaturesList,int areaEL) {
        if (currentY > 0) {
            currentY--;
            updateTable(x, y);
            checkForBattle(x, y, allCreatures, creaturesList, areaEL);
        }
    }

    private void moveRight(int x, int y, ArrayList<Creature> allCreatures,ArrayList<Creature> creaturesList,int areaEL) {
        if (currentY < y-1) {
            currentY++;
            updateTable(x, y);
            checkForBattle(x, y, allCreatures, creaturesList, areaEL);
        }
    }

    private void moveUp(int x, int y, ArrayList<Creature> allCreatures,ArrayList<Creature> creaturesList,int areaEL)
    {
       
              if (currentX > 0) {
            currentX--;
            updateTable(x, y);
            checkForBattle(x, y, allCreatures, creaturesList, areaEL);
        }
    }
    private void moveDown(int x, int y, ArrayList<Creature> allCreatures,ArrayList<Creature> creaturesList,int areaEL)
    {
      
              if (currentX < x-1) {
            currentX++;
            updateTable(x, y);
            checkForBattle(x, y, allCreatures, creaturesList, areaEL);
        }
    }
    private void updateTable(int x, int y) {
        
        tablePanel.removeAll();

       
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                JButton button = new JButton(i == currentX && j == currentY ? "x" : "");
                button.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 36));     
                button.setForeground(new Color(75, 11, 14));
                button.setBackground(new Color(243, 237, 217));
                button.setEnabled(false); // Disable button to show 'X'
                tablePanel.add(button);
            }
        }

        
        tablePanel.revalidate();
        tablePanel.repaint();
    }

    private void checkForBattle(int x, int y, ArrayList<Creature> allCreatures,ArrayList<Creature> creaturesList,int areaEL) {
      
        int random = (int) (Math.random() * 100) + 1;

        
        if (random <= 40) {
            
            JOptionPane.showMessageDialog(mainFrame, "Battle Commenced!");
            battlephaseMenu battleMenu = new battlephaseMenu(x, y, allCreatures, creaturesList, areaEL);
        }
    }
}
