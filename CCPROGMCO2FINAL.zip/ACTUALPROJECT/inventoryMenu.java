 import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.io.*;   
import java.util.*;

public class inventoryMenu {
    private JFrame mainFrame;
    private JComboBox<String> comboBox;
    private ArrayList<Creature> creaturesList;

    public inventoryMenu(ArrayList<Creature> creaturesList) {
        // Assign the creaturesList from another class
        this.creaturesList = creaturesList;

        // Create the main frame
        mainFrame = new JFrame("Pokemon Sundae");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(1230, 720);

        mainFrame.setLayout(null);

        // Set background image for the main frame
        ImageIcon backgroundImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Menu.png");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, mainFrame.getWidth(), mainFrame.getHeight());
        mainFrame.add(backgroundLabel);

        // Create a combo box with cName strings
        comboBox = new JComboBox<>();
        for (int i = 0; i < creaturesList.size(); i++) {
            Creature creature = creaturesList.get(i);
            comboBox.addItem(creature.getcName() + " - Index " + i);
        }
        comboBox.setBounds(500, 400, 200, 50); // Adjust the bounds accordingly

        // Create a confirm button
        JButton confirmButton = new JButton("confirm");
        confirmButton.setBounds(500, 500, 100, 35);
        confirmButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        confirmButton.setBackground(new Color(75, 11, 14));
        confirmButton.setForeground(new Color(243, 237, 217));
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the selected item from the combo box
                int selectedIndex = comboBox.getSelectedIndex();
                //String selectedCreatureName = (String) comboBox.getSelectedItem();
                if (selectedIndex != -1 && selectedIndex < creaturesList.size()) {
                    // Find the corresponding Creature object based on the selected index
                    Creature selectedCreature = creaturesList.get(selectedIndex);
        
                    // Show a pop-up menu with details of the selected creature
                    showCreatureDetailsPopup(selectedCreature);
                } else {
                    // Handle the case where the selected index is invalid
                    JOptionPane.showMessageDialog(null, "Error: Invalid selection!");
                }
            }
        });

        // Create a back button
        JButton backButton = new JButton("back");
        backButton.setBounds(600, 500, 100, 35);
        backButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        backButton.setBackground(new Color(75, 11, 14));
        backButton.setForeground(new Color(243, 237, 217));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
  
                mainFrame.dispose();
  
                mainMenu.pokemonSundae(creaturesList);
            }
        });

       
        backgroundLabel.add(comboBox);
        backgroundLabel.add(confirmButton);
        backgroundLabel.add(backButton);

       
        mainFrame.setVisible(true);
    }



    private void showCreatureDetailsPopup(Creature selectedCreature) {
        
        JFrame detailsFrame = new JFrame("Creature Details: " + selectedCreature.getcName());
        detailsFrame.setSize(1230, 720);
    
        
        ImageIcon creatureImageIcon = selectedCreature.getCreatureImage();
        JLabel imageLabel = new JLabel(creatureImageIcon);
    
       
        JTextArea detailsTextArea = new JTextArea();
        detailsTextArea.setEditable(false);
        detailsTextArea.setFont(new Font("Monocraft", Font.PLAIN, 35));
        detailsTextArea.setBackground(new Color(243, 237, 217));
        detailsTextArea.append("Name: " + selectedCreature.getcName() + "\n");
        detailsTextArea.append("Type: " + selectedCreature.getcType() + "\n");
        detailsTextArea.append("Family: " + selectedCreature.getcFam() + "\n");
        detailsTextArea.append("Health: " + selectedCreature.getcHealth() + "\n");
        detailsTextArea.append("Evolution Level: " + selectedCreature.getcEvLvl() + "\n");
        detailsTextArea.append("Is Active: " + selectedCreature.getIsActive() + "\n");
    
        
        JButton activateButton = new JButton("activate");
        activateButton.setBounds(600, 500, 100, 35);
        activateButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        activateButton.setBackground(new Color(75, 11, 14));
        activateButton.setForeground(new Color(243, 237, 217));
        activateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              
                for (Creature creature : creaturesList) {
                    if (creature.getcName().equals(selectedCreature.getcName()) || creature.getIsActive() == true ) {
                        creature.setIsActive(false);
                    }
                }
                
                int selectedIndex = creaturesList.indexOf(selectedCreature);
                if (selectedIndex != -1) {
                    creaturesList.get(selectedIndex).setIsActive(true);
                    
                    
                    JOptionPane.showMessageDialog(null, "Creature activated successfully!");
                } else {
                   
                    JOptionPane.showMessageDialog(null, "Error: Selected creature not found!");
                }
    
               
                detailsFrame.dispose();
            }
        });
    
      
        JButton showImageButton = new JButton("Show Image");
        showImageButton.setBounds(600, 550, 100, 35);
        showImageButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        showImageButton.setBackground(new Color(75, 11, 14));
        showImageButton.setForeground(new Color(243, 237, 217));
        showImageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               
                JFrame imageFrame = new JFrame("Creature Image");
                imageFrame.setSize(300, 300);
    
                JLabel imageLabelPopup = new JLabel(creatureImageIcon);
                imageFrame.add(imageLabelPopup);
    
                imageFrame.setVisible(true);
            }
        });
    
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout()); 
        panel.add(imageLabel, BorderLayout.NORTH);
        panel.add(new JScrollPane(detailsTextArea), BorderLayout.CENTER);
        panel.add(activateButton, BorderLayout.SOUTH);
    
    
        
        detailsFrame.add(panel);
    
        
        detailsFrame.setVisible(true);
    }
    
}
