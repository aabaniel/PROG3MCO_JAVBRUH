
 
 import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.io.*;   
import java.util.*;

public class mainMenu {

    private static JFrame frame;  // Declare frame as a class variable
 

static ArrayList<Creature> creaturesList = new ArrayList<Creature>(); 
static ArrayList<Creature> allCreatures = new ArrayList<Creature>(); 





    public static void main(String[] args) {
        String filePath = "C:/Users/disav/Desktop/Codes/ACTUALPROJECT/creatures.txt";

        allCreatures = initializeCreature.readCreaturesFromFile(filePath);

        SwingUtilities.invokeLater(() -> createAndShowGUI(creaturesList));
    }

    private static void createAndShowGUI(ArrayList<Creature> creaturesList) {
        
    Color beige = new Color(243, 237, 217);
    Color brown = new Color(75, 11, 14);
    Color banana = new Color(252, 193, 26);
  

        frame = new JFrame("Pokemon Sundae");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1230, 720);

        // Set layout to null to allow absolute positioning of components
        frame.setLayout(null);

        // Set background image
        ImageIcon backgroundImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Menu.png");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        frame.add(backgroundLabel);

        // Create "Start" button
        JButton startButton = new JButton("start");
        startButton.setBounds(300, 400, 250, 80);
        startButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 30));
        startButton.setBackground(brown);
        startButton.setForeground(beige);
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openNewScreen(creaturesList);
            }
        });

        backgroundLabel.add(startButton);


        // Create "Exit" button
        JButton exitButton = new JButton("exit");
        exitButton.setBounds(300, 500, 250, 80);
        exitButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 30));
        exitButton.setBackground(brown);
        exitButton.setForeground(beige);
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        backgroundLabel.add(exitButton);

        frame.setVisible(true);
    }

    private static void openNewScreen(ArrayList<Creature> creaturesList) {


    Color beige = new Color(243, 237, 217);
    Color brown = new Color(75, 11, 14);
    Color banana = new Color(252, 193, 26);

        JFrame newFrame = new JFrame("Pokemon Sundae");
        newFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        newFrame.setSize(1230, 720);

        // Set layout to null to allow absolute positioning of components
        newFrame.setLayout(null);


         ImageIcon newScreenImage1 = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Banvy.png");
        JLabel newScreenLabel1 = new JLabel(newScreenImage1);
        newScreenLabel1.setBounds(230, 330, 200, 200);
        newFrame.add(newScreenLabel1);
       
             ImageIcon newScreenImage2 = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Brownisaur.png");
        JLabel newScreenLabel2 = new JLabel(newScreenImage2);
        newScreenLabel2.setBounds(530, 330, 200, 200);
        newFrame.add(newScreenLabel2);

        ImageIcon newScreenImage3 = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Sherzel.png");
        JLabel newScreenLabel3 = new JLabel(newScreenImage3);
        newScreenLabel3.setBounds(850, 330, 200, 200);
        newFrame.add(newScreenLabel3);
       
       
       
        // Set background image for the new screen
        ImageIcon newScreenImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Starter.png");
        JLabel newScreenLabel = new JLabel(newScreenImage);
        newScreenLabel.setBounds(0, 0, newFrame.getWidth(), newFrame.getHeight());
        newFrame.add(newScreenLabel);

        // Add any components or actions for the new screen here
     
        


        // Dispose of the current frame (main window)
         JButton Starter1 = new JButton("Banvy");
        Starter1.setBounds(275, 570, 85, 35);
        Starter1.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        Starter1.setBackground(brown);
        Starter1.setForeground(beige);
        Starter1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            Creature Banvy = new Creature();
            Banvy.setcName("Banvy ");
            Banvy.setcType("Banana");
            Banvy.setcFam("Family A");
            Banvy.setcHealth(50);
            Banvy.setcEvLvl(1);
            Banvy.setIsActive(true);
            Banvy.setIsEnemy(false);
            ImageIcon creatureImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Banvy.png");
            Banvy.setCreatureImage(creatureImage);

            creaturesList.add(Banvy);
            newFrame.dispose();
            pokemonSundae(creaturesList);
            }
        });
        newScreenLabel.add(Starter1);

        JButton Starter2 = new JButton("Brownisaur");
        Starter2.setBounds(565, 570, 130, 35);
        Starter2.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        Starter2.setBackground(brown);
        Starter2.setForeground(beige);
        Starter2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                  
             Creature Brownisaur = new Creature();            
             Brownisaur.setcName("Brownisaur");
             Brownisaur.setcType("Chocolate");
             Brownisaur.setcFam("Family F");
             Brownisaur.setcHealth(50);
             Brownisaur.setcEvLvl(1);
             Brownisaur.setIsActive(true);
             Brownisaur.setIsEnemy(false);
             ImageIcon creatureImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Brownisaur.png");
             Brownisaur.setCreatureImage(creatureImage);

                creaturesList.add(Brownisaur);
                //newFrame.dispose();
                //pokemonSundae(creaturesList);
//////////////////////////////////////////////////////////// FOR TESTING
                Creature Brownisaur1 = new Creature();            
             Brownisaur1.setcName("Brownisaur");
             Brownisaur1.setcType("Chocolate");
             Brownisaur1.setcFam("Family F");
             Brownisaur1.setcHealth(50);
             Brownisaur1.setcEvLvl(1);
             Brownisaur1.setIsActive(false);
             Brownisaur1.setIsEnemy(false);
             ImageIcon creatureImage1 = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Brownisaur.png");
             Brownisaur1.setCreatureImage(creatureImage1);

                creaturesList.add(Brownisaur1);
                 newFrame.dispose();
                 pokemonSundae(creaturesList);
 ///////////////////////////////////////////////////////////////           
            }
        });
        newScreenLabel.add(Starter2);


         JButton Starter3 = new JButton("sherzel");
        Starter3.setBounds(893, 570, 110, 35);
        Starter3.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        Starter3.setBackground(brown);
        Starter3.setForeground(beige);
        Starter3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

             Creature Sherzel = new Creature();
             Sherzel.setcName("Sherzel");
             Sherzel.setcType("Vanilla");
             Sherzel.setcFam("Family G");
             Sherzel.setcHealth(50);
             Sherzel.setcEvLvl(1);
             Sherzel.setIsActive(true);
             Sherzel.setIsEnemy(false);
           ImageIcon creatureImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Sherzel.png");
             Sherzel.setCreatureImage(creatureImage);
                creaturesList.add(Sherzel);
                newFrame.dispose();
                pokemonSundae(creaturesList);
                
            }
        });
        newScreenLabel.add(Starter3);
        
    
        
        frame.dispose();

        newFrame.setVisible(true);
    }

public static void pokemonSundae(ArrayList<Creature> creaturesList) {

    mainMenu.creaturesList = creaturesList;

    Color beige = new Color(243, 237, 217);
    Color brown = new Color(75, 11, 14);
    Color banana = new Color(252, 193, 26);

        frame = new JFrame("Pokemon Sundae");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1230, 720);

        // Set layout to null to allow absolute positioning of components
        frame.setLayout(null);

        // Set background image
        ImageIcon backgroundImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Menu.png");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        frame.add(backgroundLabel);

        // Create "Start" button
        JButton Inventory = new JButton("inventory");
        Inventory.setBounds(300, 400, 250, 75);
        Inventory.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 30));
        Inventory.setBackground(brown);
        Inventory.setForeground(beige);
        Inventory.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                inventoryMenu inventoryMenuInstance = new inventoryMenu(creaturesList);
            }
        });
        backgroundLabel.add(Inventory);

        // Create "Exit" button
        JButton Explore = new JButton("explore");
        Explore.setBounds(300, 500, 250, 75);
        Explore.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 30));
        Explore.setBackground(brown);
        Explore.setForeground(beige);
        Explore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                areaMenu areaInstance = new areaMenu(allCreatures, creaturesList);
            }
        });
        backgroundLabel.add(Explore);

                JButton Evolve = new JButton("evolve");
        Evolve.setBounds(600, 400, 250, 75);
        Evolve.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 30));
        Evolve.setBackground(brown);
        Evolve.setForeground(beige);
        Evolve.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Evolution evolutionInstance = new Evolution();

                evolutionInstance.evolutionStart(allCreatures, creaturesList);
                
            }
        });
        backgroundLabel.add(Evolve);

        JButton Exit = new JButton("exit");
        Exit.setBounds(600, 500, 250, 75);
        Exit.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 30));
        Exit.setBackground(brown);
        Exit.setForeground(beige);
        Exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        backgroundLabel.add(Exit);

        
        frame.setVisible(true);
    }


}
