 import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.io.*;   
import java.util.*;

public class battleInventoryMenu {
    private JFrame mainFrame;
    private JComboBox<String> comboBox;
    private ArrayList<Creature> creaturesList;
    private ArrayList<Creature> allCreatures;
    private battlephaseMenu battlePhaseMenu;


    public battleInventoryMenu(battlephaseMenu battlePhaseMenu, ArrayList<Creature> creaturesList, ArrayList<Creature> allCreatures) {
        // Assign the creaturesList from another class
        this.battlePhaseMenu = battlePhaseMenu;
        this.creaturesList = creaturesList;
        this.allCreatures = allCreatures;
        // Create the main frame
        mainFrame = new JFrame("Pokemon Sundae");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(1230, 720);

        mainFrame.setLayout(null);

        // Set background image for the main frame
        ImageIcon backgroundImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Menu.png");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, mainFrame.getWidth(), mainFrame.getHeight());
        mainFrame.add(backgroundLabel);

        // Create a combo box with cName strings
        comboBox = new JComboBox<>();
        for (int i = 0; i < creaturesList.size(); i++) {
            Creature creature = creaturesList.get(i);
            comboBox.addItem(creature.getcName() + " - Index " + i);
        }
        comboBox.setBounds(500, 400, 200, 50); // Adjust the bounds accordingly

        // Create a confirm button
        JButton confirmButton = new JButton("confirm");
        confirmButton.setBounds(500, 500, 100, 35);
        confirmButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        confirmButton.setBackground(new Color(75, 11, 14));
        confirmButton.setForeground(new Color(243, 237, 217));
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the selected item from the combo box
                int selectedIndex = comboBox.getSelectedIndex();
                //String selectedCreatureName = (String) comboBox.getSelectedItem();
                if (selectedIndex != -1 && selectedIndex < creaturesList.size()) {
                    // Find the corresponding Creature object based on the selected index
                    Creature selectedCreature = creaturesList.get(selectedIndex);
        
                    // Show a pop-up menu with details of the selected creature
                    showCreatureDetailsPopup(selectedCreature);
                } else {
                    // Handle the case where the selected index is invalid
                    JOptionPane.showMessageDialog(null, "Error: Invalid selection!");
                }
            }
        });

        // Create a back button
        JButton backButton = new JButton("back");
        backButton.setBounds(600, 500, 100, 35);
        backButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        backButton.setBackground(new Color(75, 11, 14));
        backButton.setForeground(new Color(243, 237, 217));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Save changes if needed (you can add save logic here)

                // Close the current frame (inventoryMenu) and return to the main menu
                mainFrame.dispose();
                // Add code here to open your main menu or whatever your main class is called
                // Example: new YourMainMenuClass();
                battlePhaseMenu.updateActiveCreature(getSelectedCreature());
            }
        });

        // Add components to the main frame
        backgroundLabel.add(comboBox);
        backgroundLabel.add(confirmButton);
        backgroundLabel.add(backButton);

        // Set the main frame to be visible
        mainFrame.setVisible(true);
    }

    private Creature getSelectedCreature() {
        int selectedIndex = comboBox.getSelectedIndex();
        if (selectedIndex != -1 && selectedIndex < creaturesList.size()) {
            return creaturesList.get(selectedIndex);
        }
        return null;
    }


    private Creature findCreatureByName(String creatureName) {
        // Find the Creature object in the creaturesList based on the selected name
        for (Creature creature : creaturesList) {
            if (creature.getcName().equals(creatureName)) {
                return creature;
            }
        }
        return null; // Return null if not found (you might want to handle this case differently)
    }

    private void showCreatureDetailsPopup(Creature selectedCreature) {
        // Create a new frame for the selected creature details
        JFrame detailsFrame = new JFrame("Creature Details: " + selectedCreature.getcName());
        detailsFrame.setSize(1230, 720);
    
        // Create an image label to display the creature image
        ImageIcon creatureImageIcon = selectedCreature.getCreatureImage();
        JLabel imageLabel = new JLabel(creatureImageIcon);
    
        // Create a text area to display details
        JTextArea detailsTextArea = new JTextArea();
        detailsTextArea.setEditable(false);
        detailsTextArea.setFont(new Font("Monocraft", Font.PLAIN, 35));
        detailsTextArea.setBackground(new Color(243, 237, 217));
        detailsTextArea.append("Name: " + selectedCreature.getcName() + "\n");
        detailsTextArea.append("Type: " + selectedCreature.getcType() + "\n");
        detailsTextArea.append("Family: " + selectedCreature.getcFam() + "\n");
        detailsTextArea.append("Health: " + selectedCreature.getcHealth() + "\n");
        detailsTextArea.append("Evolution Level: " + selectedCreature.getcEvLvl() + "\n");
        detailsTextArea.append("Is Active: " + selectedCreature.getIsActive() + "\n");
    
        // Create an "Activate" button
        JButton activateButton = new JButton("activate");
        activateButton.setBounds(600, 500, 100, 35);
        activateButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        activateButton.setBackground(new Color(75, 11, 14));
        activateButton.setForeground(new Color(243, 237, 217));
        activateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Set the selected creature to active
                //selectedCreature.setIsActive(true);
                

                // Search the creaturesList for other active creatures and set them to inactive
                for (Creature creature : creaturesList) {
                    if (creature.getcName().equals(selectedCreature.getcName()) || creature.getIsActive() == true ) {
                        creature.setIsActive(false);
                    }
                }
                
                int selectedIndex = creaturesList.indexOf(selectedCreature);
                if (selectedIndex != -1) {
                    creaturesList.get(selectedIndex).setIsActive(true);
                    
                    // Show a success message
                    JOptionPane.showMessageDialog(null, "Creature activated successfully!");
                } else {
                    // Handle the case where the selectedCreature is not found in the list
                    JOptionPane.showMessageDialog(null, "Error: Selected creature not found!");
                }
    
                // Close the details frame and go back to the inventory menu
                detailsFrame.dispose();
            }
        });
    
        // Create a "Show Image" button
        JButton showImageButton = new JButton("Show Image");
        showImageButton.setBounds(600, 550, 100, 35);
        showImageButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 12));
        showImageButton.setBackground(new Color(75, 11, 14));
        showImageButton.setForeground(new Color(243, 237, 217));
        showImageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a pop-up window to show the creature image
                JFrame imageFrame = new JFrame("Creature Image");
                imageFrame.setSize(300, 300);
    
                JLabel imageLabelPopup = new JLabel(creatureImageIcon);
                imageFrame.add(imageLabelPopup);
    
                imageFrame.setVisible(true);
            }
        });
    
        // Create a panel and add the image label, text area, "Activate" button, and "Show Image" button
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout()); // Use BorderLayout for organized layout
        panel.add(imageLabel, BorderLayout.NORTH);
        panel.add(new JScrollPane(detailsTextArea), BorderLayout.CENTER);
        panel.add(activateButton, BorderLayout.SOUTH);
        //panel.add(showImageButton, BorderLayout.SOUTH);
    
        // Add the panel to the details frame
        detailsFrame.add(panel);
    
        // Set the details frame to be visible
        detailsFrame.setVisible(true);
    }
    
}
