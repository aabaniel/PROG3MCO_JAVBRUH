import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
// User selects two same creatures from two different dropdowns from the same inventory

// if the user fails to choose two unique duplicate creatures, the user receives a popup and the loop repeats

// Alternatively, if they choose correctly, the user recieves a popup about the evolution details and asks the user if they accept the evolution process.

// if no, the user is sent back to the evolution menu, if yes, the process of evolution is proceded.

// the two chosen unique duplicate creatures will be deleted and will be replaced by a creature with a higher evolution level, and same family ID. 


public class Evolution extends JFrame{
    private JFrame mainFrame;
    Creature creature1 = new Creature();
    Creature creature2 = new Creature();
    Creature EVOcreature = new Creature();
    JComboBox<String> creatureDropdown1 = new JComboBox<>();
    JComboBox<String> creatureDropdown2 = new JComboBox<>();
    ArrayList<Creature> creaturesList;
    ArrayList<Creature> allCreatures;
    ArrayList<Creature> dupliList = new ArrayList<>();
    int scIndex1, scIndex2;
    private JTextArea creatureDetailsTextArea;
    private JTextArea EVOCreatureText;
    private JLabel EVOImageLabel;
    private JLabel creatureImageLabel;

    public void evolutionStart(ArrayList<Creature> allCreatures, ArrayList<Creature> creaturesList)
    {
    this.creaturesList = creaturesList;
    this.allCreatures = allCreatures;
    
     mainFrame = new JFrame("Pokemon Sundae");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(1230, 720);
        mainFrame.setLayout(null);
        mainFrame.setVisible(true);
        ImageIcon backgroundImage = new ImageIcon("C:/Users/disav/Desktop/Codes/ACTUALPROJECT/pokemon/Evolve.png");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, mainFrame.getWidth(), mainFrame.getHeight());
        

        for (Creature creature : creaturesList)
            creatureDropdown1.addItem(creature.getcName() + " (evLvl: " + creature.getcEvLvl() + ")");

        creatureDropdown1.setBounds(175, 400, 300, 100); // Adjust the bounds accordingly
        creatureDropdown1.setFont(new Font("Monospaced", Font.PLAIN, 20));

        // Create a confirm button
        JButton confirmButton = new JButton("confirm");
        confirmButton.setBounds(175, 500, 150, 50);
        confirmButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 20));
        confirmButton.setBackground(new Color(75, 11, 14));
        confirmButton.setForeground(new Color(243, 237, 217));
        confirmButton.addActionListener(new ActionListener() {
            @Override
                public void actionPerformed(ActionEvent e) {
                // Get the selected item from the combo box
                scIndex1 = creatureDropdown1.getSelectedIndex();
                creature1 = creaturesList.get(scIndex1);

                ImageIcon cIcon1 = new ImageIcon(creature1.getCreatureImage().getImage());

                JOptionPane.showMessageDialog(mainFrame, "Active Player Creature Details:\nName: " + creature1.getcName() + "\nType: " + creature1.getcType() + "\nHealth: " + creature1.getcHealth() + "\n", "Creature Details", JOptionPane.INFORMATION_MESSAGE, cIcon1);

                dupliList = new ArrayList<>(creaturesList);
                dupliList.remove(scIndex1);

                creatureDropdown2.removeAllItems();
                for (Creature creature : dupliList) {
                    creatureDropdown2.addItem(creature.getcName() + " (evLvl: " + creature.getcEvLvl() + ")");
                }

                creatureDropdown2.setBounds(700, 400, 300, 100);
                creatureDropdown2.setFont(new Font("Monospaced", Font.PLAIN, 20));

                    ////////////////////////////////////////////////////////////////////////////////
                    JButton confirmButton1 = new JButton("confirm");
                    confirmButton1.setBounds(700, 500, 150, 50);
                    confirmButton1.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 20));
                    confirmButton1.setBackground(new Color(75, 11, 14));
                    confirmButton1.setForeground(new Color(243, 237, 217));
                    confirmButton1.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            // Get the selected item from the combo box
                            String selectedCreatureName1 = (String) creatureDropdown1.getSelectedItem();
                            scIndex1 = creatureDropdown1.getSelectedIndex();

                            String selectedCreatureName2 = (String) creatureDropdown2.getSelectedItem();
                            scIndex2 = creatureDropdown2.getSelectedIndex();
                            creature2 = creaturesList.get(scIndex2);
                            ImageIcon cIcon2 = new ImageIcon(creature2.getCreatureImage().getImage());

                            JOptionPane.showMessageDialog(mainFrame, "Creature 2 Details:\nName: " + creature2.getcName() + "\nType: " + creature2.getcType() + "\nHealth: " + creature2.getcHealth() + "\n", "Creature Details", JOptionPane.INFORMATION_MESSAGE, cIcon2);

                            if (scIndex1 != scIndex2 && selectedCreatureName1.equals(selectedCreatureName2) || dupliList.size() == 1 && selectedCreatureName1.equals(selectedCreatureName2)) {

                                evolutionFinal(allCreatures, creaturesList, EVOcreature, creature1, creature2);
                            } else {
                                JOptionPane.showMessageDialog(mainFrame, "Invalid Selection!!!");
                            }

                        }
                    });

                mainFrame.add(confirmButton1);
            }
        });

        //mainFrame.add(creatureDetailsTextArea);
        
        mainFrame.add(confirmButton);
        mainFrame.add(creatureDropdown1);
        mainFrame.add(creatureDropdown2);
        mainFrame.add(backgroundLabel);
    }


    public void evolutionFinal(ArrayList<Creature> allCreatures, ArrayList<Creature> creaturesList, Creature EVOcreature,Creature creature1,Creature creature2) {
        int evlvl = creature1.getcEvLvl() + 1;
        for(Creature creature : allCreatures){
            if(creature.getcFam().equals(creature1.getcFam()) && creature.getcEvLvl().equals(evlvl)){
                EVOcreature.setcName(creature.getcName());
                EVOcreature.setcType(creature.getcType());
                EVOcreature.setcFam(creature.getcFam());
                EVOcreature.setcHealth(creature.getcHealth());
                EVOcreature.setcEvLvl(creature1.getcEvLvl());
                EVOcreature.setIsActive(creature.getIsActive());
                EVOcreature.setIsEnemy(creature.getIsEnemy());
                EVOcreature.setCreatureImage(creature.getCreatureImage());
                break;
            }
        }
        
        creaturesList.add(EVOcreature);
        creaturesList.remove(scIndex2);
        creaturesList.remove(scIndex1);
        

        //JOptionPane.showMessageDialog(mainFrame, creaturesList.get(scIndex1).getcName());

        ImageIcon cIconE = new ImageIcon(EVOcreature.getCreatureImage().getImage());
        JOptionPane.showMessageDialog(mainFrame, "Evolution Details:\nName: " + EVOcreature.getcName() + "\nType: " + EVOcreature.getcType() + "\nHealth: " + EVOcreature.getcHealth() + "\n", "Creature Details", JOptionPane.INFORMATION_MESSAGE, cIconE);

 
       // mainFrame.add(backButton);
        JButton backButton = new JButton("back");
        backButton.setBounds(850, 500, 150, 50);
        backButton.setFont(new Font("VanDoesburgArchiType", Font.PLAIN, 20));
        backButton.setBackground(new Color(75, 11, 14));
        backButton.setForeground(new Color(243, 237, 217));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Save changes if needed (you can add save logic here)

                // Close the current frame (inventoryMenu) and return to the main menu
                mainFrame.dispose();
                // Add code here to open your main menu or whatever your main class is called
                // Example: new YourMainMenuClass();
                mainMenu.pokemonSundae(creaturesList);
            }
        });
        mainFrame.add(backButton);
    }

}

    
      